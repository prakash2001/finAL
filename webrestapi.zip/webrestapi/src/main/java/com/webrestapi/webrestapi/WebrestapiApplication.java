package com.webrestapi.webrestapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebrestapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebrestapiApplication.class, args);
	}
}
